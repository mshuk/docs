/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testingtool;

import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;

public class testing2 {
    public static void main(String[] args)throws Exception {

        File file = new File("SECOND.bin");

        Scanner sc = new Scanner(file);
        String lastString = "";
        String st="";

        while (sc.hasNextLine()) {
            String line = sc.nextLine();
            lastString = lastString + line;
            System.out.println(lastString);
        }
        char[] result = new char[lastString.length() / 7];
    
        for (int i = 0; i < lastString.length(); i += 7) {
                String sub = lastString.substring(i, i + 7);
                result[i / 7] = (char) Integer.parseInt(sub, 2);
        }   
        //System.out.println(new String(result));
        int i=result.length;
        //String st="";
        for (int x=result.length; x>0; x--){
                i=i - 1;
                st += new String(result).substring(i, x);
            
        }
        System.out.println(st);
        PrintWriter fileOut = new PrintWriter ("THIRD.txt");
        try{
            fileOut.printf (st);
        }finally{
              fileOut.close();
        }
    } 
    
}
