/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testingtool;

import java.io.IOException;
//import java.util.Scanner;
//import java.io.*;

/**
 *
 * @author Administrator
 */
public class testing {
    public static void main(String[] args) throws IOException {
        String s = "10000011000010100001110001001000101100011010001111001000100100110010101001011100110010011011001110100111110100001010001101001010100111010100101010110101101010111101100010110011011010";
        String t;
        int i=182;
        System.out.println("Number of character in s = " + s.length());
        for (int x=182; x>0; x=x-7){
            i=i-7;
            t=s.substring(i, x);
            int r=Integer.parseInt(t);
            
            System.out.println(r + " -> " + t);
            
            
        }
    }
    
    
}
